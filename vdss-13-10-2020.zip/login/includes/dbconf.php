<?php
//DATABASE CONNECTION VARIABLES
$host = "localhost"; // Host name
$username = "user"; // Mysql username
$password = ""; // Mysql password
$db_name = "drivingschool"; // Database name
$host = "localhost"; // Host name
$username = "valleydr_valley2"; // Mysql username
$password = "hT8Wru5VD2"; // Mysql password
$db_name = "valleydr_driving"; // Database name
//DO NOT CHANGE BELOW THIS LINE UNLESS YOU CHANGE THE NAMES OF THE MEMBERS AND LOGINATTEMPTS TABLES

$tbl_prefix = ""; //***PLANNED FEATURE, LEAVE VALUE BLANK FOR NOW*** Prefix for all database tables
$tbl_members = $tbl_prefix."members";
$student_information = $tbl_prefix."student_information";
$tbl_attempts = $tbl_prefix."loginAttempts";
